//In this exercise, you will be measuring the analog
//voltages of a compounded circuit.

//Use your code from previous exercises to perform this.

//Print the values to the terminal screen.

//Thoroughly comment your code and demonstrate to the
//lab instructor.


//Use g++ -std=c++11 -o Lab3EX3 Lab3EX3.cpp -lwiringPi

//Evelyn Wilson and Gavin McKee
//Lab 3 Exercise 3
#include <iostream>
#include <unistd.h>
#include <wiringPi.h>
#include <wiringPiI2C.h>
#include <signal.h>
#include <stdlib.h>
using namespace std;


int adc;
int ratio;
void stop(int);
int adcVal();

int main(){
	//Initialize the wiringPi Library.
    signal(SIGINT, stop);
	wiringPiSetupGpio();
	double inputVoltage;
	double actualVoltage;
	//Set mode of digital pins.
	pinMode(18, OUTPUT);
	pinMode(23, OUTPUT);
	pinMode(24, OUTPUT);
	pinMode(25, OUTPUT);
	while(true){
		//Place the values for 0 - 15 here.
		//0 (0000)
		digitalWrite(25, LOW);
		digitalWrite(24, LOW);
		digitalWrite(23, LOW);
		digitalWrite(18, LOW);

		inputVoltage = adcVal(); //takes input voltage
		actualVoltage = (inputVoltage/2047) * 4096; //converts to millivolts
		cout << "The converted analog voltage for the binary input 0000 to R-2R ladder is " << actualVoltage << endl;
		usleep(10000000); //1 second of sleep

		//1 (0001)
		digitalWrite(25, LOW); //0
		digitalWrite(24, LOW); //0
		digitalWrite(23, LOW); //0
		digitalWrite(18, HIGH);//1

		inputVoltage = adcVal(); //takes input voltage
		actualVoltage = (inputVoltage/2047) * 4096; // converts to millivolts
		cout << "The converted analog voltage for the binary input 0001 to R-2R ladder is " << actualVoltage << endl;
		usleep(10000000); //1 second of sleep

		//2 (0010)
		digitalWrite(25, LOW); //0
		digitalWrite(24, LOW); //0
		digitalWrite(23, HIGH);//1
		digitalWrite(18, LOW); //0

		inputVoltage = adcVal();//takes input voltage
		actualVoltage = (inputVoltage/2047) * 4096; //converts to millivolts
		cout << "The converted analog voltage for the binary input 0010 to R-2R ladder is " << actualVoltage << endl;
		usleep(10000000); //1 second of sleep

		//3 (0011)
		digitalWrite(25, LOW); //0
		digitalWrite(24, LOW); //0
		digitalWrite(23, HIGH);//1
		digitalWrite(18, HIGH);//1

		inputVoltage = adcVal();//takes input voltage
		actualVoltage = (inputVoltage/2047) * 4096;//converts to millivolts
		cout << "The converted analog voltage for the binary input 0011 to R-2R ladder is " << actualVoltage << endl;
		usleep(10000000);//1 second of sleep

		//4 (0100)
		digitalWrite(25, LOW); //0
		digitalWrite(24, HIGH);//1
		digitalWrite(23, LOW); //0
		digitalWrite(18, LOW); //0

		inputVoltage = adcVal();
		actualVoltage = (inputVoltage/2047) * 4096;
		cout << "The converted analog voltage for the binary input 0100 to R-2R ladder is " << actualVoltage << endl;
		usleep(10000000);

		//5 (0101)
		digitalWrite(25, LOW); //0
		digitalWrite(24, HIGH);//1
		digitalWrite(23, LOW); //0
		digitalWrite(18, HIGH);//1

		inputVoltage = adcVal();
		actualVoltage = (inputVoltage/2047) * 4096;
		cout << "The converted analog voltage for the binary input 0101 to R-2R ladder is " << actualVoltage << endl;
		usleep(10000000);

		//6 (0110)
		digitalWrite(25, LOW); //0
		digitalWrite(24, HIGH);//1
		digitalWrite(23, HIGH);//1
		digitalWrite(18, LOW); //0

		inputVoltage = adcVal();
		actualVoltage = (inputVoltage/2047) * 4096;
		cout << "The converted analog voltage for the binary input 0110 to R-2R ladder is " << actualVoltage << endl;
		usleep(10000000);

		//7 (0111)
		digitalWrite(25, LOW); //0
		digitalWrite(24, HIGH);//1
		digitalWrite(23, HIGH);//1
		digitalWrite(18, HIGH);//1

		inputVoltage = adcVal();
		actualVoltage = (inputVoltage/2047) * 4096;
		cout << "The converted analog voltage for the binary input 0111 to R-2R ladder is " << actualVoltage << endl;
		usleep(10000000);

		//8 (1000)
		digitalWrite(25, HIGH);//1
		digitalWrite(24, LOW); //0
		digitalWrite(23, LOW); //0
		digitalWrite(18, LOW); //0

		inputVoltage = adcVal();
		actualVoltage = (inputVoltage/2047) * 4096;
		cout << "The converted analog voltage for the binary input 1000 to R-2R ladder is " << actualVoltage << endl;
		usleep(10000000);

		//9 (1001)
		digitalWrite(25, HIGH);//1
		digitalWrite(24, LOW); //0
		digitalWrite(23, LOW); //0
		digitalWrite(18, HIGH);//1

		inputVoltage = adcVal();
		actualVoltage = (inputVoltage/2047) * 4096;
		cout << "The converted analog voltage for the binary input 1001 to R-2R ladder is " << actualVoltage << endl;
		usleep(10000000);

		//10 (1010)
		digitalWrite(25, HIGH);//1
		digitalWrite(24, LOW); //0
		digitalWrite(23, HIGH);//1
		digitalWrite(18, LOW); //0

		inputVoltage = adcVal();
		actualVoltage = (inputVoltage/2047) * 4096;
		cout << "The converted analog voltage for the binary input 1010 to R-2R ladder is " << actualVoltage << endl;
		usleep(10000000);

		//11 (1011)
		digitalWrite(25, HIGH);//1
		digitalWrite(24, LOW); //0
		digitalWrite(23, HIGH);//1
		digitalWrite(18, HIGH);//1

		inputVoltage = adcVal();
		actualVoltage = (inputVoltage/2047) * 4096;
		cout << "The converted analog voltage for the binary input 1011 to R-2R ladder is " << actualVoltage << endl;
		usleep(10000000);

		//12 (1100)
		digitalWrite(25, HIGH);//1
		digitalWrite(24, HIGH);//1
		digitalWrite(23, LOW); //0
		digitalWrite(18, LOW); //0

		inputVoltage = adcVal();
		actualVoltage = (inputVoltage/2047) * 4096;
		cout << "The converted analog voltage for the binary input 1100 to R-2R ladder is " << actualVoltage << endl;
		usleep(10000000);

		//13 (1101)
		digitalWrite(25, HIGH);//1
		digitalWrite(24, HIGH);//1
		digitalWrite(23, LOW); //0
		digitalWrite(18, HIGH);//1

		inputVoltage = adcVal();
		actualVoltage = (inputVoltage/2047) * 4096;
		cout << "The converted analog voltage for the binary input 1101 to R-2R ladder is " << actualVoltage << endl;
		usleep(10000000);

		//14 (1110)
		digitalWrite(25, HIGH);//1
		digitalWrite(24, HIGH);//1
		digitalWrite(23, HIGH);//1
		digitalWrite(18, LOW); //0

		inputVoltage = adcVal();
		actualVoltage = (inputVoltage/2047) * 4096;
		cout << "The converted analog voltage for the binary input 1110 to R-2R ladder is " << actualVoltage << endl;
		usleep(10000000);

		//15 (1111)
		digitalWrite(25, HIGH);//1
		digitalWrite(24, HIGH);//1
		digitalWrite(23, HIGH);//1
		digitalWrite(18, HIGH);//1

		inputVoltage = adcVal();
		actualVoltage = (inputVoltage/2047) * 4096;
		cout << "The converted analog voltage for the binary input 1111 to R-2R ladder is " << actualVoltage << endl;
		usleep(10000000);

	}
}


//This function is used to read data from ADS1015
int adcVal(){

	uint16_t low, high, value;
    // Refer to the supplemental documents to find the parameters.
	adc = wiringPiI2CSetup(0x48);
	wiringPiI2CWriteReg16(adc, 0x01, 0xC583);
	usleep(1000);
    uint16_t data = wiringPiI2CReadReg16(adc,0x00);


    low = (data & 0xFF00) >> 8;
    high = (data & 0x00FF) << 8;
    value = (high | low)>>4;
	if (value > 0x07FF)
        {
            value |= 0xF000;
        }
	return (int16_t) value;
}

void stop(int sig){exit(1);}
